package Ex5_5;

import org.springframework.context.annotation.*;

@Configuration
@ComponentScan(basePackages = { "com.example" })
public class JavaConfig {
	// operand
	// minusOp(defaultOperator)
	// plusOp
}

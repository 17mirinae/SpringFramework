package Ex5_5;

public interface OperatorBean {
	int calc();

	void setOperand1(Operand op1);

	void setOperand2(Operand op1);
	
	Operand getOperand1();
	
	Operand getOperand2();
}

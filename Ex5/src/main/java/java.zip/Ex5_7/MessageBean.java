package Ex5_7;

public interface MessageBean {
	void sayHello(String name);
}

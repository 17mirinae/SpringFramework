package Ex5_8;

public interface MessageBean {
	void sayHello(String name);
}
